export const SectionContent = ( { children } ) => {
	return <div className='sectionContent'>{ children }</div>
}