export const HeadlineTitle = ( { children } ) => {
	return <div className='headlineTitle'><h1>{ children }</h1></div>
}